#!/bin/bash

# 客服系统停止脚本

echo "🛑 停止客服系统..."

# 查找进程
PID=$(pgrep -f "kefu-system" || true)

if [ -n "$PID" ]; then
    echo "📊 找到进程 PID: $PID"
    echo "🔄 发送停止信号..."
    kill -TERM "$PID"
    
    # 等待进程结束
    for i in {1..10}; do
        if ! kill -0 "$PID" 2>/dev/null; then
            echo "✅ 服务已停止"
            exit 0
        fi
        sleep 1
    done
    
    # 强制停止
    echo "⚠️ 强制停止进程..."
    kill -KILL "$PID" 2>/dev/null || true
    echo "✅ 服务已强制停止"
else
    echo "ℹ️ 未找到运行中的服务"
fi
