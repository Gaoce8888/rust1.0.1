#!/bin/bash

# 客服系统启动脚本
# 使用方法: ./start.sh [环境]

set -e

# 默认环境
ENVIRONMENT=${1:-development}
CONFIG_FILE="config/app-config.${ENVIRONMENT}.json"

echo "🚀 启动客服系统..."
echo "📊 环境: ${ENVIRONMENT}"
echo "📁 配置文件: ${CONFIG_FILE}"

# 检查配置文件
if [ ! -f "${CONFIG_FILE}" ]; then
    echo "❌ 配置文件不存在: ${CONFIG_FILE}"
    echo "💡 可用的配置文件:"
    ls -la config/app-config.*.json 2>/dev/null || echo "   无配置文件"
    exit 1
fi

# 检查二进制文件
if [ ! -f "bin/kefu-system" ]; then
    echo "❌ 二进制文件不存在: bin/kefu-system"
    exit 1
fi

# 创建必要的目录
mkdir -p logs
mkdir -p data

# 设置环境变量
export APP_ENV="${ENVIRONMENT}"
export RUST_LOG="info"

# 启动服务
echo "✅ 启动服务..."
exec ./bin/kefu-system
