#!/bin/bash

# 依赖检查脚本

echo "🔍 检查系统依赖..."

# 检查动态库依赖
echo "📋 动态库依赖:"
if command -v ldd >/dev/null 2>&1; then
    ldd bin/kefu-system
else
    echo "❌ ldd 命令不可用"
fi

echo ""
echo "📋 系统库检查:"

# 检查 OpenSSL
if ldconfig -p | grep -q libssl; then
    echo "✅ libssl: 已安装"
else
    echo "❌ libssl: 未安装"
fi

# 检查 OpenSSL crypto
if ldconfig -p | grep -q libcrypto; then
    echo "✅ libcrypto: 已安装"
else
    echo "❌ libcrypto: 未安装"
fi

# 检查 zlib
if ldconfig -p | grep -q libz; then
    echo "✅ libz: 已安装"
else
    echo "❌ libz: 未安装"
fi

# 检查 zstd
if ldconfig -p | grep -q libzstd; then
    echo "✅ libzstd: 已安装"
else
    echo "❌ libzstd: 未安装"
fi

# 检查 GCC 运行时
if ldconfig -p | grep -q libgcc_s; then
    echo "✅ libgcc_s: 已安装"
else
    echo "❌ libgcc_s: 未安装"
fi

echo ""
echo "📋 网络端口检查:"
echo "💡 确保以下端口可用:"
echo "   - 6006: HTTP API 服务"
echo "   - 6007: WebSocket 服务"
echo "   - 6379: Redis 服务 (如果使用外部 Redis)"

echo ""
echo "📋 文件权限检查:"
if [ -r "bin/kefu-system" ]; then
    echo "✅ 二进制文件可读"
else
    echo "❌ 二进制文件不可读"
fi

if [ -x "bin/kefu-system" ]; then
    echo "✅ 二进制文件可执行"
else
    echo "❌ 二进制文件不可执行"
fi

if [ -w "logs" ]; then
    echo "✅ 日志目录可写"
else
    echo "❌ 日志目录不可写"
fi

if [ -w "data" ]; then
    echo "✅ 数据目录可写"
else
    echo "❌ 数据目录不可写"
fi
