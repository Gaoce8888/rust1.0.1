// 类型定义文件
// 当前为空，可以在此处添加 TypeScript 类型定义或 JSDoc 类型注释
export {};
