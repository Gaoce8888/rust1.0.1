// PostCSS configuration in CommonJS format to avoid ESM module errors caused by ESM exports
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
