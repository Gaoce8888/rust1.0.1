#!/bin/bash

# 客服系统安装脚本

set -e

echo "🔧 安装客服系统..."

# 检查系统要求
echo "📋 检查系统要求..."

# 检查操作系统
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "✅ 操作系统: Linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    echo "✅ 操作系统: macOS"
else
    echo "❌ 不支持的操作系统: $OSTYPE"
    exit 1
fi

# 检查架构
ARCH=$(uname -m)
if [[ "$ARCH" == "x86_64" ]]; then
    echo "✅ 架构: x86_64"
elif [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
    echo "✅ 架构: ARM64"
else
    echo "⚠️ 未知架构: $ARCH"
fi

# 检查依赖库
echo "📋 检查依赖库..."

# 检查 OpenSSL
if ldconfig -p | grep -q libssl; then
    echo "✅ OpenSSL: 已安装"
else
    echo "❌ OpenSSL: 未安装"
    echo "💡 安装命令:"
    echo "   Ubuntu/Debian: sudo apt install libssl-dev"
    echo "   CentOS/RHEL: sudo yum install openssl-devel"
    echo "   macOS: brew install openssl"
fi

# 检查 zlib
if ldconfig -p | grep -q libz; then
    echo "✅ zlib: 已安装"
else
    echo "❌ zlib: 未安装"
    echo "💡 安装命令:"
    echo "   Ubuntu/Debian: sudo apt install zlib1g-dev"
    echo "   CentOS/RHEL: sudo yum install zlib-devel"
    echo "   macOS: brew install zlib"
fi

# 检查 zstd
if ldconfig -p | grep -q libzstd; then
    echo "✅ zstd: 已安装"
else
    echo "❌ zstd: 未安装"
    echo "💡 安装命令:"
    echo "   Ubuntu/Debian: sudo apt install libzstd-dev"
    echo "   CentOS/RHEL: sudo yum install libzstd-devel"
    echo "   macOS: brew install zstd"
fi

# 创建系统服务
echo "📋 创建系统服务..."

SERVICE_FILE="/etc/systemd/system/kefu-system.service"
INSTALL_DIR=$(pwd)

if [ -w /etc/systemd/system ]; then
    cat > "$SERVICE_FILE" << SERVICE_EOF
[Unit]
Description=Kefu System Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/bin/kefu-system
Restart=always
RestartSec=5
Environment=APP_ENV=production
Environment=RUST_LOG=info

[Install]
WantedBy=multi-user.target
SERVICE_EOF

    echo "✅ 系统服务已创建: $SERVICE_FILE"
    echo "💡 启用服务: sudo systemctl enable kefu-system"
    echo "💡 启动服务: sudo systemctl start kefu-system"
    echo "💡 查看状态: sudo systemctl status kefu-system"
else
    echo "⚠️ 无法创建系统服务 (需要 root 权限)"
    echo "💡 手动创建服务文件: $SERVICE_FILE"
fi

echo "✅ 安装完成！"
echo "🚀 启动服务: ./start.sh production"
