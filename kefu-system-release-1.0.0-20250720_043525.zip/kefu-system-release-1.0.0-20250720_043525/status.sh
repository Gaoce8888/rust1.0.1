#!/bin/bash

# 客服系统状态检查脚本

echo "📊 客服系统状态检查"

# 检查进程
PID=$(pgrep -f "kefu-system" || true)

if [ -n "$PID" ]; then
    echo "✅ 服务运行中 (PID: $PID)"
    
    # 检查端口
    if command -v netstat >/dev/null 2>&1; then
        echo "🌐 端口监听状态:"
        netstat -tlnp 2>/dev/null | grep kefu-system || echo "   未找到端口监听"
    fi
    
    # 检查内存使用
    if command -v ps >/dev/null 2>&1; then
        echo "💾 内存使用:"
        ps -o pid,ppid,cmd,%mem,%cpu --no-headers -p "$PID" 2>/dev/null || echo "   无法获取进程信息"
    fi
else
    echo "❌ 服务未运行"
fi

# 检查日志文件
echo "📝 日志文件状态:"
if [ -d "logs" ]; then
    ls -la logs/ 2>/dev/null || echo "   日志目录为空"
else
    echo "   日志目录不存在"
fi

# 检查数据目录
echo "💾 数据目录状态:"
if [ -d "data" ]; then
    ls -la data/ 2>/dev/null || echo "   数据目录为空"
else
    echo "   数据目录不存在"
fi
