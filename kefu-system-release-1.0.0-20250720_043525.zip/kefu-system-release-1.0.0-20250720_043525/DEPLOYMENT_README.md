# 客服系统部署指南

## 📦 包信息
- **版本**: 1.0.0
- **构建日期**: $(date)
- **架构**: x86_64
- **二进制大小**: 11MB

## 🚀 快速开始

### 1. 检查依赖
```bash
./check_dependencies.sh
```

### 2. 安装系统服务 (可选)
```bash
sudo ./install.sh
```

### 3. 启动服务
```bash
# 开发环境
./start.sh development

# 生产环境
./start.sh production
```

### 4. 检查状态
```bash
./status.sh
```

### 5. 停止服务
```bash
./stop.sh
```

## 📋 系统要求

### 必需依赖
- **OpenSSL**: libssl.so.3, libcrypto.so.3
- **zlib**: libz.so.1
- **zstd**: libzstd.so.1
- **GCC 运行时**: libgcc_s.so.1
- **标准 C 库**: libc.so.6, libm.so.6

### 安装依赖 (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install libssl-dev zlib1g-dev libzstd-dev
```

### 安装依赖 (CentOS/RHEL)
```bash
sudo yum install openssl-devel zlib-devel libzstd-devel
```

### 安装依赖 (macOS)
```bash
brew install openssl zlib zstd
```

## 📁 目录结构
```
kefu-system/
├── bin/                    # 二进制文件
│   └── kefu-system        # 主程序
├── config/                 # 配置文件
│   ├── app-config.json    # 主配置
│   ├── app-config.development.json
│   ├── app-config.production.json
│   └── address_config.toml
├── data/                   # 数据目录
├── logs/                   # 日志目录
├── static/                 # 静态文件
├── docs/                   # 文档
├── scripts/                # 脚本
├── start.sh               # 启动脚本
├── stop.sh                # 停止脚本
├── status.sh              # 状态检查
├── install.sh             # 安装脚本
└── check_dependencies.sh  # 依赖检查
```

## ⚙️ 配置说明

### 环境配置
- **development**: 开发环境配置
- **production**: 生产环境配置

### 主要配置项
- **服务器端口**: 6006 (HTTP), 6007 (WebSocket)
- **Redis 配置**: 本地 Redis 或外部 Redis
- **日志级别**: info, debug, warn, error
- **数据目录**: ./data
- **日志目录**: ./logs

## 🔧 故障排除

### 常见问题

1. **权限错误**
   ```bash
   chmod +x bin/kefu-system
   chmod +x *.sh
   ```

2. **依赖缺失**
   ```bash
   ./check_dependencies.sh
   # 根据输出安装缺失的依赖
   ```

3. **端口被占用**
   ```bash
   netstat -tlnp | grep :6006
   # 停止占用端口的进程
   ```

4. **配置文件错误**
   ```bash
   # 检查配置文件语法
   cat config/app-config.json | jq .
   ```

### 日志查看
```bash
# 实时日志
tail -f logs/app.log

# 错误日志
tail -f logs/error.log
```

## 📞 技术支持

如遇到问题，请检查：
1. 系统依赖是否完整
2. 配置文件是否正确
3. 端口是否被占用
4. 文件权限是否正确
5. 日志文件中的错误信息

## 📄 许可证

本项目采用 MIT 许可证。
